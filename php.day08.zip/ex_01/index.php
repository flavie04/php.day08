<?php
echo "Hello world"
?>