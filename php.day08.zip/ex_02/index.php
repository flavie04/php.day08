<?php
$name = $_GET["name"];
    if ($name) {
        echo "Hello ".$name;" !\n";
    }
    else { 
        echo "hello platypus !\n";
    }
?>